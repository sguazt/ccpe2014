dcsxx-commons
=============

A set of C++ libraries aimed at providing common reusable, general-purpose components