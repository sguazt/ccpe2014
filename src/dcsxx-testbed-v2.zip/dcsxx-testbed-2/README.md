dcsxx-testbed
=============

A set of C++ components for setting up and managing a real computing testbed.

The system under test (SUT) is managed by exploiting virtualization technologies and, in particular, by using the libvirt library (http://www.libvirt.org).
This testbed allows the experimenter to perform both system identification and resource management experiments
