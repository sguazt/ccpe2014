dcsxx-sysid
===========

A set of C++ libraries aimed at providing system identification functionalities.