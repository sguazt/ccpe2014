dcsxx-control
=============

A set of C++ libraries aimed at providing control theoretic functionalities.