boost-ublasx
============

Extensions to Boost.uBLAS library