set :application, "perf"
set :user, 'cs198-gb'
set :local_user, 'wsobel'
set :group_num, 22

load 'vendor/plugins/rorclassify/rorclassify'
