INSERT INTO rubis_bdb.bids SELECT * FROM rubis.bids;
INSERT INTO rubis_bdb.buy_now SELECT * FROM rubis.buy_now;
INSERT INTO rubis_bdb.categories SELECT * FROM rubis.categories;
INSERT INTO rubis_bdb.comments SELECT * FROM rubis.comments;
INSERT INTO rubis_bdb.items SELECT * FROM rubis.items;
INSERT INTO rubis_bdb.old_items SELECT * FROM rubis.old_items;
INSERT INTO rubis_bdb.regions SELECT * FROM rubis.regions;
INSERT INTO rubis_bdb.users SELECT * FROM rubis.users;
