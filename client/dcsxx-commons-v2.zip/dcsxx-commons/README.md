dcsxx-commons
=============

A set of C++ libraries aimed at providing common reusable, general-purpose components


Building
--------

### Prerequisites

* A modern C++98 compiler (e.g., GCC v4.8 or newer is fine)
* [Boost](http://boost.org) C++ libraries (v1.54 or newer)

### Compilation

This is a header-only library and thus it does not need to be compiled.
